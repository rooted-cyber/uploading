pwd
ls
wget -O u.zip https://raw.githubusercontent.com/rooted-cyber/uploading/main/ab
unzip u.zip
bash start.sh