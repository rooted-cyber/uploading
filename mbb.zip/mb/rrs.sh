ab() {
pip3 install --no-cache-dir anytree
pip3 install --no-cache-dir appdirs
pip3 install --no-cache-dir aria2p
pip3 install --no-cache-dir asyncio
pip3 install --no-cache-dir attrdict
pip3 install --no-cache-dir beautifulsoup4
pip3 install --no-cache-dir bencoding
pip3 install --no-cache-dir cfscrape
pip3 install --no-cache-dir feedparser
pip3 install --no-cache-dir flask
pip3 install --no-cache-dir google-api-python-client
pip3 install --no-cache-dir google-auth-httplib2
pip3 install --no-cache-dir google-auth-oauthlib
pip3 install --no-cache-dir gunicorn
pip3 install --no-cache-dir lk21
pip3 install --no-cache-dir lxml
pip3 install --no-cache-dir pillow
pip3 install --no-cache-dir psutil
pip3 install --no-cache-dir psycopg2-binary
pip3 install --no-cache-dir pybase64
pip3 install --no-cache-dir pyrogram
pip3 install --no-cache-dir python-dotenv
pip3 install --no-cache-dir python-magic
pip3 install --no-cache-dir python-telegram-bot
pip3 install --no-cache-dir qbittorrent-api
pip3 install --no-cache-dir requests
pip3 install --no-cache-dir telegraph
pip3 install --no-cache-dir tenacity
pip3 install --no-cache-dir tgCrypto
pip3 install --no-cache-dir urllib3
pip3 install --no-cache-dir yt-dlp
}
pip install --upgrade pip
apt update -y
apt upgrade -y
apt install --fix-broken -y
apt install clang -y
ab


